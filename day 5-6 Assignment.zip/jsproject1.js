Employees=[
    {
        name:"Teja",
        age:24,
        city:"kerala",
        salary:200000

    },

    {
        name:"Ashish",
        age:23,
        city:"hyderabad",
        salary:30000
    },

    {
        name:"harish",
        age:26,
        city:"indore",
        salary:45000
    },

    {
        name:"Rajesh",
        age:24,
        city:"nandyal",
        salary:220000
    },

    {
        name:"Subash",
        age:30,
        city:"araku",
        salary:400000
    }
]

function display(show){
    document.getElementById("tbody").innerHTML=""

   show.forEach((ele,i)=>{
        document.getElementById("tbody").innerHTML+=`<tr>
        <td>${i+1}</td>
        <td>${ele.name}</td>
        <td>${ele.age}</td>
        <td>${ele.city}</td>
        <td>${ele.salary}</td>
        <td><button class="btn btn-primary" onclick="deleterow(${i})">Delete</button></td>      
        </tr>`
   })
         
}

display(Employees);

function searchbyname(){
    searchname=document.getElementById("name").value
    let result=Employees.filter((ele,i)=>{
        return ele.name.toLowerCase().indexOf(searchname.toLowerCase())!=-1;
    })

    // console.log(result)
    display(result)
    
}

function searchbycity(){
    searchcity=document.getElementById("city").value;
    let result=Employees.filter((ele,i)=>{
        return ele.city.toLowerCase().indexOf(searchcity.toLowerCase())!=-1;

    })

    // console.log(result)
    display(result)
}

function deleterow(i){
    Employees.splice(i,1)
    display(Employees)

}