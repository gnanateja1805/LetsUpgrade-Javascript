function changeImage() {
       const ele = document.getElementById("image");
       const newUrl="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTpoAm_UvQDtF0Z7CmASVnmtd2sSSqoT-3F8g&usqp=CAU";
    ele.src=newUrl;   
}

function changeImage2(){
    const ele = document.getElementById("image2");
    const newUrl="https://www.tollywood.net/wp-content/uploads/2020/01/Humble-and-Calm-Jr-NTR-upset.jpg";
  ele.src=newUrl;  
}

function changeImage3(){
    const ele = document.getElementById("image3");
    const newUrl="https://www.tollywood.net/wp-content/uploads/2020/01/Humble-and-Calm-Jr-NTR-upset.jpg";
  ele.src=newUrl; 
}