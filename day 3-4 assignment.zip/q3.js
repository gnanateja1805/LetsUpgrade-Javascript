let data = [
    {
        name:"teja",
        age:"21",
        country:"India",
        hobbies:["playing badminton","watching tech videos"]
    },
    {
        name:"gnana",
        age:"22",
        country:"canada",
        hobbies:["playing","studying"]
    },
    {
        name:"loshi",
        age:"32",
        country:"India",
        hobbies:["dancing","reading"]
    },
    {
        name:"nivi",
        age:"33",
        country:"california",
        hobbies:["studying","singing"]
    },

];
 console.log(data);