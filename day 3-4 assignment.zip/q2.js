function change(){
    const elem=document.getElementsByClassName("input text");
    console.log(elem[1].value=elem[0].value);
}